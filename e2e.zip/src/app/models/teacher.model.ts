export class Teacher {
    id: number;
    firstName: String;
    lastName: String;
    emailAddress: String;
    teacherSalary: number;
    password: String;
}
