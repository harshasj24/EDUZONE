export * from './course.model';
export * from './student.model';
export * from './teacher.model';
export * from './admin.model';