export class Course {
    id: number;
    courseName: String;
    coursePoints: number;
    courseDescription: String;
    courseImageUrl: String;
}