export class Student {
    id: number;
    firstName: String;
    lastName: String;
    homeAddress: String;
    emailAddress: String;
    studentPoints: number;
    password: String;
}